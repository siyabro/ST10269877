/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package siyalibrarymanagementsystem;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Book {
    private final int bookId;
    String title;
    String author;
    private boolean isAvailable;

    public Book(int bookId, String title, String author) {
        this.bookId = bookId;
        this.title = title;
        this.author = author;
        this.isAvailable = true;
    }

    public int getBookId() {
        return bookId;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void setAvailable(boolean isAvailable) {
        this.isAvailable = isAvailable;
    }

    public void displayBookInfo() {
        System.out.println("===============");
        System.out.println("Book ID: " + bookId);
        System.out.println("Title: " + title);
        System.out.println("Author: " + author);
        System.out.println("Available: " + isAvailable);
        System.out.println("===============");
    }
}

class Library {
    private final List<Book> books = new ArrayList<>();

    public void addBook(Book book) {
        books.add(book);
    }

    public void updateBook(int bookId, String newTitle, String newAuthor) {
        for (Book book : books) {
            if (book.getBookId() == bookId) {
                book.setAvailable(true);
                book.title = newTitle;
                book.author = newAuthor;
                return;
            }
        }
        System.out.println("Book not found.");
    }

    public void deleteBook(int bookId) {
        books.removeIf(book -> book.getBookId() == bookId);
    }

    public Book findBook(int bookId) {
        return books.stream().filter(book -> book.getBookId() == bookId).findFirst().orElse(null);
    }

    public void displayLibrary() {
        for (Book book : books) {
            book.displayBookInfo();
        }
    }
}

/**
 *
 * @author lab_services_student
 */
public class SiyaLibraryManagementSystem {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Library library = new Library();

        // Adding some initial books to the library
        library.addBook(new Book(1, "Book 1", "Author 1"));
        library.addBook(new Book(2, "Book 2", "Author 2"));

        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nLibrary Management System");
            System.out.println("1. Add Book");
            System.out.println("2. Update Book");
            System.out.println("3. Delete Book");
            System.out.println("4. Search for Book");
            System.out.println("5. Display Library");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter Book ID: ");
                    int bookId = scanner.nextInt();
                    System.out.print("Enter Title: ");
                    String title = scanner.next();
                    System.out.print("Enter Author: ");
                    String author = scanner.next();

                    library.addBook(new Book(bookId, title, author));
                    break;

                case 2:
                    System.out.print("Enter Book ID to update: ");
                    int updateId = scanner.nextInt();
                    System.out.print("Enter new Title: ");
                    String newTitle = scanner.next();
                    System.out.print("Enter new Author: ");
                    String newAuthor = scanner.next();

                    library.updateBook(updateId, newTitle, newAuthor);
                    break;

                case 3:
                    System.out.print("Enter Book ID to delete: ");
                    int deleteId = scanner.nextInt();

                    library.deleteBook(deleteId);
                    break;

                case 4:
                    System.out.print("Enter Book ID to search: ");
                    int searchId = scanner.nextInt();

                    Book foundBook = library.findBook(searchId);
                    if (foundBook != null) {
                        foundBook.displayBookInfo();
                    } else {
                        System.out.println("Book not found.");
                    }
                    break;

                case 5:
                    library.displayLibrary();
                    break;

                case 6:
                    System.exit(0);
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        }
    }
}