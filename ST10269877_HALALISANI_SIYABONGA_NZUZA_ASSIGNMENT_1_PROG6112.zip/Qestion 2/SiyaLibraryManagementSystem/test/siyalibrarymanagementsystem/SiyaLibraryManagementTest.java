/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package siyalibrarymanagementsystem;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author lab_services_student
 */
public class SiyaLibraryManagementTest {
    
    public SiyaLibraryManagementTest() {
    }
     @Test
    public void testAddBook() {
        Library library = new Library();
        Book book = new Book(1, "Sample Book", "Sample Author");
        library.addBook(book);
        assertEquals(1, library.findBook(1).getBookId());
    }

    @Test
    public void testUpdateBook() {
        Library library = new Library();
        Book book = new Book(1, "Sample Book", "Sample Author");
        library.addBook(book);
        library.updateBook(1, "Updated Book", "Updated Author");
        assertEquals("Updated Book", library.findBook(1).getTitle());
    }

    @Test
    public void testDeleteBook() {
        Library library = new Library();
        Book book = new Book(1, "Sample Book", "Sample Author");
        library.addBook(book);
        library.deleteBook(1);
        assertNull(library.findBook(1));
    }

    @Test
    public void testFindBook() {
        Library library = new Library();
        Book book = new Book(1, "Sample Book", "Sample Author");
        library.addBook(book);
        assertNotNull(library.findBook(1));
    }

    @Test
    public void testDisplayLibrary() {
        Library library = new Library();
        Book book1 = new Book(1, "Book 1", "Author 1");
        Book book2 = new Book(2, "Book 2", "Author 2");
        library.addBook(book1);
        library.addBook(book2);
        
    }

    @Test
    public void testAddBookNotAvailableByDefault() {
        Library library = new Library();
        assertFalse(library.findBook(1).isAvailable());
    }

    @Test
    public void testUpdateBookAvailability() {
        Library library = new Library();
        Book book = new Book(1, "Sample Book", "Sample Author");
        library.addBook(book);
        library.updateBook(1, "Updated Book", "Updated Author");
        assertTrue(library.findBook(1).isAvailable());
    }

    @Test
    public void testDeleteBookAvailability() {
        Library library = new Library();
        Book book = new Book(1, "Sample Book", "Sample Author");
        library.addBook(book);
        library.deleteBook(1);
        assertNull(library.findBook(1));
    }

    @Test
    public void testNonExistentBookSearch() {
        Library library = new Library();
        assertNull(library.findBook(1));
    }

    @Test
    public void testInvalidBookUpdate() {
        Library library = new Library();
        Book book = new Book(1, "Sample Book", "Sample Author");
        library.addBook(book);
        library.updateBook(2, "Updated Book", "Updated Author");
        assertEquals("Sample Book", library.findBook(1).getTitle());
    }

    @Test
    public void testDisplayEmptyLibrary() {
        Library library = new Library();
        
    }

    @Test
    public void testInvalidChoice() {
        Library library = new Library();
        assertEquals(-1, library.findBook(0).getBookId());
    }

    @Test
    public void testExitSystem() {
        Library library = new Library();
        library.displayLibrary(); 
    }
}
