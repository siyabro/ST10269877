/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignment1;

/**
 *
 * @author lab_services_student
 */
public class Student {
    public final String studentId;
    public final String studentName;
    public final int studentAge;
    public final String studentEmail;
    public final String studentCourse;

    public Student(String id, String name, int age, String email, String course) {
        studentId = id;
        studentName = name;
        studentAge = age;
        studentEmail = email;
        studentCourse = course;
    }

    public String getStudentId() {
        return studentId;
    }

    public boolean isAgeValid() {
        return studentAge >= 16;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Student student = (Student) obj;
        return studentAge == student.studentAge &&
                studentId.equals(student.studentId) &&
                studentName.equals(student.studentName) &&
                studentEmail.equals(student.studentEmail) &&
                studentCourse.equals(student.studentCourse);
    }
}