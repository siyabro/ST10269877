/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package assignment1;
import java.util.ArrayList;
import java.util.Scanner;

public class StudentManagement {
    public static final ArrayList<Student> students = new ArrayList<>();
    public static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            showMenu();
        }
    }

    public static void showMenu() {
        System.out.println("STUDENT MANAGEMENT APPLICATION");
        System.out.println("************************************************");
        System.out.println("Please select one of the following menu items:");
        System.out.println("(1) Capture a new student.");
        System.out.println("(2) Search for a student.");
        System.out.println("(3) Delete a student.");
        System.out.println("(4) Print student report.");
        System.out.println("(5) Exit Application");

        int choice = getUserChoice();

        switch (choice) {
    case 1 -> captureStudent();
    case 2 -> {
        System.out.print("Enter the student id to search: ");
        String searchId = scanner.nextLine();
        searchStudent(searchId);
    }
    case 3 -> {
        System.out.print("Enter the student id to delete: ");
        String deleteId = scanner.nextLine();
        deleteStudent(deleteId);
    }
    case 4 -> studentReport();
    case 5 -> exitApplication();
    default -> System.exit(0);
}
    }

    public static int getUserChoice() {
        while (true) {
            try {
                System.out.print("Enter your choice: ");
                return Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid choice.");
            }
        }
    }

    public static void captureStudent() {
        System.out.print("Enter the student id: ");
        String studentId = scanner.nextLine();
        System.out.print("Enter the student name: ");
        String studentName = scanner.nextLine();
        System.out.print("Enter the student age: ");
        String studentAgeStr = scanner.nextLine();
        System.out.print("Enter the student email: ");
        String studentEmail = scanner.nextLine();
        System.out.print("Enter the student course: ");
        String studentCourse = scanner.nextLine();

        try {
            int studentAge = Integer.parseInt(studentAgeStr);
            if (studentAge >= 16) {
                Student student = new Student(studentId, studentName, studentAge, studentEmail, studentCourse);
                students.add(student);
                System.out.println("Student details have been successfully saved.");
            } else {
                System.out.println("You have entered an incorrect student age! Please re-enter a valid age.");
            }
        } catch (NumberFormatException e) {
            System.out.println("You have entered an incorrect student age! Please re-enter a valid age.");
        }
    }

    public static Student searchStudent(String studentId) {
    // Search for the student with the given ID
    for (Student student : students) {
        if (student.getStudentId().equals(studentId)) {
            System.out.println(student.toString());
            return student; // Return the found student
        }
    }

    // If no student is found, return null
    return null;
}


    public static boolean deleteStudent(String studentId) {
    boolean deleted = false;

    for (int i = 0; i < students.size(); i++) {
        if (students.get(i).getStudentId().equals(studentId)) {
            System.out.print("Are you sure you want to delete student " + studentId + " from the system? (yes/no): ");
            String confirm = scanner.nextLine().toLowerCase();
            if (confirm.equals("yes")) {
                students.remove(i);
                System.out.println("Student with id: " + studentId + " was DELETED!");
                deleted = true;
                break;
            }
        }
    }

    if (!deleted) {
        System.out.println("Student with id: " + studentId + " was not found!");
    }

    return deleted;
}
    public static void studentReport() {
    int count = 1;

    for (Student student : students) {
        System.out.println("Student " + count);
        System.out.println("---------------------------------------");
        System.out.println("Student ID      : " + student.studentId);
        System.out.println("Student NAME    : " + student.studentName);
        System.out.println("Student AGE     : " + student.studentAge);
        System.out.println("Student EMAIL   : " + student.studentEmail);
        System.out.println("Student COURSE  : " + student.studentCourse);
        System.out.println();

        count++;
    }
}
  
    public static void exitApplication() {
        System.out.println("Exiting the application.");
        System.exit(0);
    }
}

