/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package assignment1;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
/**
 *
 * @author lab_services_student
 */
public class StudentManagementTest {

    @Test
    public void TestSaveStudent() {
        
        Student student = new Student("1", "John Doe", 20, "john@example.com", "Math");

        StudentManagement.students.add(student);

        Student savedStudent = StudentManagement.students.get(0);

        assertEquals(student, savedStudent);
    }

    @Test
public void TestSearchStudent() {
    
    Student student = new Student("1", "John Doe", 20, "john@example.com", "Math");

    
    StudentManagement.students.add(student);

    
    Student retrievedStudent = StudentManagement.searchStudent("1");

    assertEquals(student, retrievedStudent);
}

    @Test
    public void TestSearchStudent_StudentNotFound() {
        
        Student retrievedStudent = StudentManagement.searchStudent("2");

        assertNull(retrievedStudent);
    }

    @Test
public void TestDeleteStudent() {
 
    Student student = new Student("1", "John Doe", 20, "john@example.com", "Math");

    StudentManagement.students.add(student);
    boolean isDeleted = StudentManagement.deleteStudent("1");
    assertTrue(isDeleted);
    
    Student deletedStudent = StudentManagement.searchStudent("1");

    assertNull(deletedStudent);
}


    @Test
public void TestDeleteStudent_StudentNotFound() {
    boolean isDeleted = StudentManagement.deleteStudent("2");
    assertFalse(isDeleted);
}

    @Test
    public void TestStudentAge_StudentAgeValid() {
        
        Student student = new Student("1", "Alice Smith", 18, "alice@example.com", "History");

        assertTrue(student.isAgeValid());
    }

    @Test
    public void TestStudentAge_StudentAgeInvalid() {
        
        Student student = new Student("2", "Bob Johnson", 15, "bob@example.com", "Chemistry");

        assertFalse(student.isAgeValid());
    }

    @Test
public void TestStudentAge_StudentAgeInvalidCharacter() {
 
    Student student = new Student("3", "Charlie Brown", 0, "charlie@example.com", "Art");

    assertFalse(student.isAgeValid());
}
}